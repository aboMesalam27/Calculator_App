import 'package:flutter/material.dart';
import 'package:splashscreen/splashscreen.dart';

import 'home_screen.dart';

class MainSplash extends StatefulWidget {
  const MainSplash({Key key}) : super(key: key);
  @override
  _MainSplashState createState() => _MainSplashState();
}

class _MainSplashState extends State<MainSplash> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          body: SplashScreen(
        useLoader: true,
        loadingText: const Text(
          "Welcome To Calculator",
          style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
        ),
        navigateAfterSeconds: HomeScreen(),
        seconds: 4,
        loaderColor: Colors.black,
        image: Image.asset("assets/calculator1.jpg"),
        photoSize: 190,
      )),
    );
  }
}
